import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // telling hibernate that below class is an Entity - means it must have primary key
@Table(name="dept") //telling hibernate that the table is dept 
public class Department {
	
	@Id //telling hibernate that departmentNumber is the PK
	@Column(name="deptno") //means the actual column name is deptno and not departmentNumber
	private int departmentNumber;

	@Column(name="dname") //actual column is dname 
	private String departmentName;
	
	@Column(name="loc")
	private String departmentLocation;
	
	public Department() {
		System.out.println("Department() ctor");
	}

	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentLocation() {
		return departmentLocation;
	}

	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}
	
}
