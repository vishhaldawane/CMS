import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TestDepartment {
	
	EntityManager entityManager;///a program to perform CRUD ON ANY TABLE
	
	public TestDepartment() {
		//acquire the factory
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("MyJPA"); //META-INF\persistence.xml -> u find it there
		System.out.println("got the entity manager factory : "+factory);
		
		this.entityManager = factory.createEntityManager();
		System.out.println("got the entity manager  : "+entityManager);	
	}
	
	
	@Test
	public void insertSingleRecordInDeptTest() {
		
		Department dept = new Department(); //blank object
		System.out.println("Department is instantitated...");

		dept.setDepartmentNumber(50);//fill up the primary key
		dept.setDepartmentName("EXAM"); //other details
		dept.setDepartmentLocation("NEW MUMBAI"); //and so on
		System.out.println("dept object filled up");
		
		
		EntityTransaction tx = entityManager.getTransaction();
		System.out.println("transaction started..."+tx);
		tx.begin();
			entityManager.persist(dept); //insert query fired
			
			System.out.println("object persisted....");
		tx.commit();
		System.out.println("transaction committed...");
		
		
	}

	
	@Test
	public void selectSingleRecordOfDeptTest() {
		
		Department dept = null; //blank object
		System.out.println("Department is instantitated...");
		
		dept = entityManager.find(Department.class, 10);
		
		System.out.println("DEPTNO : "+dept.getDepartmentNumber());
		System.out.println("DNAME  : "+dept.getDepartmentName());
		System.out.println("LOC    : "+dept.getDepartmentLocation());		
	}

	

	@Test
	public void selectAllRecordsOfDeptTest() {
		
		List<Department> deptList = new ArrayList<Department>();	
		System.out.println("Department is instantitated...");
		
		TypedQuery<Department> query  = entityManager.createQuery("from Department", Department.class) ;//JPQL - here it is not the TABLE NAME in the from clause | it is the POJO in the QUERY  
		deptList = query.getResultList();
		
		for(Department dept : deptList) {
			System.out.println("DEPTNO : "+dept.getDepartmentNumber());
			System.out.println("DNAME  : "+dept.getDepartmentName());
			System.out.println("LOC    : "+dept.getDepartmentLocation());
			System.out.println("----------------------");
		}
	}

	
	@Test
	public void updateSingleRecordInDeptTest() {
		
		Department dept = null; //blank object
		System.out.println("Department is instantitated...");
		EntityTransaction tx = entityManager.getTransaction();
		System.out.println("transaction started..."+tx);
		tx.begin();
				dept = entityManager.find(Department.class,40); //SELECT QUERY
				System.out.println("--CURRENT VALUES --");
				System.out.println("DEPTNO : "+dept.getDepartmentNumber());
				System.out.println("DNAME  : "+dept.getDepartmentName());
				System.out.println("LOC    : "+dept.getDepartmentLocation());
				
				dept.setDepartmentName("OPR");
				dept.setDepartmentLocation("WASHINGTON");
				
				entityManager.merge(dept); //UPDATE
				
				
		tx.commit();
		System.out.println("transaction committed...");
		
		
	}

	
	@Test
	public void deleteSingleRecordInDeptTest() {
		
		Department dept = null; //blank object
		System.out.println("Department is instantitated...");
		EntityTransaction tx = entityManager.getTransaction();
		System.out.println("transaction started..."+tx);
		tx.begin();
				dept = entityManager.find(Department.class,60); //SELECT QUERY
				System.out.println("--CURRENT VALUES --");
				System.out.println("DEPTNO : "+dept.getDepartmentNumber());
				System.out.println("DNAME  : "+dept.getDepartmentName());
				System.out.println("LOC    : "+dept.getDepartmentLocation());
				entityManager.remove(dept); //DELETE QUERY
		tx.commit();
		System.out.println("transaction committed...");
	}

}

/*
 * 2016
 10 days = 240 hours shutdown the mouth
 
	@Test
	public void sampleTest() {
		System.out.println("Test begin");
		Assertions.assertTrue(10>50);
		System.out.println("passed1");
		
		Assertions.assertTrue(10>3);
		System.out.println("passed2");

		
		Assertions.assertTrue(10>2);
		System.out.println("passed3");


		System.out.println("Test end");
		
	}



*/