import { Component } from '@angular/core';
import { Pizza } from '../Pizza';
import { PizzaService } from '../pizza.service';
import { MyResponse } from '../MyResponse';

@Component({
  selector: 'app-add-pizza',
  templateUrl: './add-pizza.component.html',
  styleUrls: ['./add-pizza.component.css']
})
export class AddPizzaComponent {

  //below object is null, but angular will inject it 
  constructor(private pizzaService: PizzaService) {}

  pizzaObj : Pizza = new Pizza(); //blank | but filled up by html
        //when the add button is clicked below function invoked
  response!: MyResponse;

  addPizza() {
    console.log('addPizza() invoked...',this.pizzaObj);
    this.pizzaService.addPizzaToDB(this.pizzaObj).subscribe
    ({
      next: (gotResponse:MyResponse) => {
        //alert('pizza added');
        this.response = gotResponse;
        alert(this.response.message);
        console.log('SUCCESS=>',this.response.message);
      },
      error: (error) => {
        //this.message="not added";
        this.response.message = error.msg;
        console.log('ERROR=>',this.response.message);
      }
    })
    

  }
}
