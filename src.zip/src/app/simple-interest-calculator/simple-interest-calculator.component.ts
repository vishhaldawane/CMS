import { Component } from '@angular/core';

@Component({
  
  selector: 'app-simple-interest-calculator',
  templateUrl: './simple-interest-calculator.component.html',
  styleUrls: ['./simple-interest-calculator.component.css']
})
export class SimpleInterestCalculatorComponent {

  //STEP 1
  p: number=10000;
  n: number=5;
  r: number=7.5;
  si: number=0;

  //STEP2
  calculateSI() { //this function to be executed based on click from the html button 
   // alert("hello calculateSI() function");
    console.log("calculate si invoked...");
    console.log('p ',this.p);
    console.log('n ',this.n);
    console.log('r ',this.r);

    this.si=(this.p*this.n*this.r)/100;
    console.log('si ',this.si);

  }
  
}


