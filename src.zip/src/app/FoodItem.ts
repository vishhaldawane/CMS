export class FoodItem {
    
}
