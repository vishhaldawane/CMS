import { Component } from '@angular/core';
import { Account } from './registration/Account';
import { Student } from './Student'; //NO .ts as extension

@Component({ 
  selector: 'app-root',  
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {// app.component.ts
  title = 'Welcome to Scheme For Farmers and Bidders';

  accObj : Account  = new Account();

  studentObj : Student = new Student();

  //but constructor in angular is constructor() { }
  constructor() { // constructor in java is name of the class
    console.log('AppComponent() constructor called...');
    this.accObj.accountNumber=1000;
    this.accObj.accountHolderName="Jacky";
    this.accObj.accountBalance=50000;
    this.accObj.accountOpeningDate= new Date();

    this.studentObj.rollNumber=900;
    this.studentObj.studentName="Peter";
    
  }

  //lets learn data types
  
//make 4 new variable here below
     driverID: number=100;
  driverIDHolderName: string="Chethan";
  driverIDOpeningDate: Date = new Date();

}

