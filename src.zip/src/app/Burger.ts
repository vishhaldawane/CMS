import { FoodItem } from "./FoodItem";

export class Burger extends FoodItem
{
     burgerId !: number;
	 burgerName!: string;
	 burgerDescription!: string;
}


