import { Component } from '@angular/core';

@Component({
  selector: 'my-login',
  templateUrl: './login.component.html', //VIEW
  styleUrls: ['./login.component.css'] //STYLE
})
export class LoginComponent { //LOGIC

}
