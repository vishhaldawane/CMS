export class Student {

    rollNumber!: number;
    studentName!: string;

    

}