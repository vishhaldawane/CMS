export class MyResponse
{
    message!: string;
    statusCode! : number;

}