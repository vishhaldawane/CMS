import { Component } from '@angular/core';
import { CalculatorService } from '../calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent {
  num1!: number;
  num2!: number;
  ans!: number;

  constructor(private calciService: CalculatorService) {

  }
  add() {  //local add function is invoking service's addTwoNumberService() function
   // this.ans = this.num1+ this.num2;
    console.log('invoking add()....calling service....');
    this.ans=this.calciService.addTwoNumberService(this.num1,this.num2);
    console.log('add is over...',this.ans);
  
  }
  subtract() { 
    console.log('subtract() invoked');
    
  }
  multiply() { 
    console.log('multiply() invoked');
    
  }
  divide() {
    console.log('divide() invoked');
    
   }

}
