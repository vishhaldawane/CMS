import { FoodItem } from "./FoodItem";

export class Pizza extends FoodItem
{
     pizzaId !: number;
	 pizzaName!: string;
	 pizzaDescription!: string;
	 pizzaImageURL!: string;
}


