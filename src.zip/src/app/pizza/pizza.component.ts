import { Component } from '@angular/core';
import { Pizza } from '../Pizza';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-pizza',
  templateUrl: './pizza.component.html',
  styleUrls: ['./pizza.component.css']
})
export class PizzaComponent {

  pizzasArray!: Pizza[]; //referred by html page of this compo


  constructor(private pizzaService: PizzaService) {
    console.log('constructor of PizzaComponent invoking service..')
    //this.pizzasArray = this.pizzaService.loadAllPizzas();
    this.pizzaService.loadAllPizzasFromDB().
    subscribe(pizzaLocalAry => {
      console.log(pizzaLocalAry);
      this.pizzasArray = pizzaLocalAry;
    } );


  }
}
