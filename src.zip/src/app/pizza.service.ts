import { Injectable } from '@angular/core';
import { Pizza } from './Pizza';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PizzaService {

  pizzas: Pizza[] = [];

  constructor(private myhttp: HttpClient) { 

    this.pizzas[0] = new Pizza();
    this.pizzas[1] = new Pizza();
    this.pizzas[2] = new Pizza();

    this.pizzas[0].pizzaId=1;
    this.pizzas[0].pizzaName="Corn Pizza";
    this.pizzas[0].pizzaDescription="Its sweet one";

    this.pizzas[1].pizzaId=2;
    this.pizzas[1].pizzaName="Cheese Pizza";
    this.pizzas[1].pizzaDescription="Its cheesy one";


    this.pizzas[2].pizzaId=3;
    this.pizzas[2].pizzaName="Mashroom Pizza";
    this.pizzas[2].pizzaDescription="Its good one";



  }

  loadAllPizzas() : Pizza[] {
      console.log('loading all pizzas from PizzaService');
      return this.pizzas;
  }

  baseURL='http://localhost:8080/food/takeOrder/Chicken/Chicken'

    
  loadAllPizzasFromDB() : Observable<Pizza[]> {
    console.log('loading all pizzas from PizzaService via Spring controller');
    return  this.myhttp.get<Pizza[]>(this.baseURL);//SPRING's controller
}

}
