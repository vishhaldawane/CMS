import { Injectable } from '@angular/core';
import { Pizza } from './Pizza';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MyResponse } from './MyResponse';

@Injectable({
  providedIn: 'root'
})
export class PizzaService {

  pizzas: Pizza[] = [];

  constructor(private myhttp: HttpClient) { }

  baseURL='http://localhost:8080/food/takeOrder/Chicken/Chicken'

  loadAllPizzas() : Pizza[] {
      console.log('loading all pizzas from PizzaService');
      return this.pizzas;
  }
    
  loadAllPizzasFromDB() : Observable<Pizza[]> {
    console.log('loading all pizzas from PizzaService via Spring controller');
    return  this.myhttp.get<Pizza[]>(this.baseURL);//SPRING's controller
  }

  addPizzaToDB(pizzaToAdd: Pizza) : Observable<MyResponse> {
    console.log('addPizzaToDB() invoked..');
    return this.myhttp.post<MyResponse>('http://localhost:8080/food/addPizza',pizzaToAdd);
  }
  

}
