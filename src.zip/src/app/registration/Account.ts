export class Account {
    
  accountNumber!: number;
  accountHolderName!: string;
  accountBalance!: number ;
  accountOpeningDate!: Date;

} //create teh object of above class in app component 