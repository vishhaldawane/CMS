import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {
  addTwoNumberService(x: number, y: number) : number {
    console.log('addTwoNumberService() invoked...')
    return x + y;
  }
}
