package com.cms.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cms.project.layer2.FoodItem;
import com.cms.project.layer2.Pizza;

@Service
public interface FoodService { //service is not repo
	List<FoodItem> orderMeal(String someHint1, String someHint2);
	List<FoodItem> orderMeal(String someHint1);

	void addPizzaService(Pizza pizza);
	void modifyPizzaService(Pizza pizza);
	void deletePizzaService(int  pizzaId);
	
	
}
