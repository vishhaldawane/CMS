package com.cms.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzaProjectApplication.class, args);
		System.out.println("Pizza appliation started...");
	}

}
