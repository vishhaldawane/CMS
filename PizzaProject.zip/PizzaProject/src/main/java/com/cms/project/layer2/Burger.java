package com.cms.project.layer2;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Component //spring's component
@Entity //JAP entity too
@Table(name="burger_tbl") //mapped with this table
public class Burger extends FoodItem {

	@Id //with pk
	@GeneratedValue //SEQUENCE 
	@Column(name="burger_id")
	int burgerId;
	
	@Column(name="burger_name",length=30)
	String burgerName;
	
	@Column(name="burger_descrip",length=30)
	String burgerDescription;

	public int getBurgerId() {
		return burgerId;
	}

	public void setBurgerId(int burgerId) {
		this.burgerId = burgerId;
	}

	public String getBurgerName() {
		return burgerName;
	}

	public void setBurgerName(String burgerName) {
		this.burgerName = burgerName;
	}

	public String getBurgerDescription() {
		return burgerDescription;
	}

	public void setBurgerDescription(String burgerDescription) {
		this.burgerDescription = burgerDescription;
	}

	
	
	
}
