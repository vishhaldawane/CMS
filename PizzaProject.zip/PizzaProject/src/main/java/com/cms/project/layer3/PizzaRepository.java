package com.cms.project.layer3;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cms.project.layer2.Pizza;

@Repository
public interface PizzaRepository  extends CrudRepository<Pizza,Integer> 
{

	
}
//we dont have to implement PizzaRepository
//cause spring f/w would provide a class
//who will implement our PizzaRepository
//WHY? 


interface Reactive
{
	void react();	
}
interface Responsive extends  Reactive
{
}


class Student implements Responsive
{
	public void react() { }
}