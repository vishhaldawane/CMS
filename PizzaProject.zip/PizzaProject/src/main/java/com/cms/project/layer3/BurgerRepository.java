package com.cms.project.layer3;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cms.project.layer2.Burger;
import com.cms.project.layer2.Pizza;

@Repository
public interface BurgerRepository  extends CrudRepository<Burger,Integer> 
{

	
}
