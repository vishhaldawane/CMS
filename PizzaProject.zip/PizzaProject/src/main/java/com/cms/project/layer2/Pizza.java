package com.cms.project.layer2;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Component //spring's component
@Entity //JAP entity too
@Table(name="pizza_tbl") //mapped with this table
public class Pizza extends FoodItem {

	@Id //with pk
	@GeneratedValue //SEQUENCE 
	@Column(name="pizza_id")
	int pizzaId;
	
	@Column(name="pizza_name",length=30)
	String pizzaName;
	
	@Column(name="pizza_descrip",length=30)
	String pizzaDescription;
	
	@Column(name="pizza_ImageURL", length=50)
	String pizzaImageURL;
	
	
	public String getPizzaImageURL() {
		return pizzaImageURL;
	}

	public void setPizzaImageURL(String pizzaImageURL) {
		this.pizzaImageURL = pizzaImageURL;
	}

	public int getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}

	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public String getPizzaDescription() {
		return pizzaDescription;
	}

	public void setPizzaDescription(String pizzaDescription) {
		this.pizzaDescription = pizzaDescription;
	}
	
	
	
}
