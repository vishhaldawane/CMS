package com.cms.project.myexceptions;

public class PizzaAlreadyExistsException extends Exception {

	public PizzaAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
