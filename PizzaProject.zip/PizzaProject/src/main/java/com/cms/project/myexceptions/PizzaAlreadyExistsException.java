package com.cms.project.myexceptions;

public class PizzaAlreadyExistsException extends RuntimeException {

	public PizzaAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
