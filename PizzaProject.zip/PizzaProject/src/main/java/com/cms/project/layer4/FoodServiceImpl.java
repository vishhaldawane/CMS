package com.cms.project.layer4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.project.layer2.Burger;
import com.cms.project.layer2.FoodItem;
import com.cms.project.layer2.Pizza;
import com.cms.project.layer3.BurgerRepository;
import com.cms.project.layer3.PizzaRepository;
import com.cms.project.myexceptions.PizzaAlreadyExistsException;

@Service
public class FoodServiceImpl implements FoodService {

	@Autowired
	PizzaRepository pizzaRepo;
	
	@Autowired
	BurgerRepository burgerRepo;
	
	
	public List<FoodItem> orderMeal(String someHint1) //Chicken
	{
		return orderMeal(someHint1,someHint1);
	}
	
	@Override
	public List<FoodItem> orderMeal(String someHint1, String someHint2) {

		List<FoodItem> foundFoodItemList = new ArrayList<FoodItem>();
		
		Iterable<Pizza> pizzaIterable = pizzaRepo.findAll();
		Iterator<Pizza> pizzaIterator = pizzaIterable.iterator();
		while(pizzaIterator.hasNext()) {
			Pizza foundPizza = pizzaIterator.next();
			if(foundPizza.getPizzaName().contains(someHint1)) {
				foundFoodItemList.add(foundPizza);
			}
		}
		
		Iterable<Burger> burgerIterable = burgerRepo.findAll();
		Iterator<Burger> burgerIterator = burgerIterable.iterator();
		while(burgerIterator.hasNext()) {
			Burger foundBurger = burgerIterator.next();
			if(foundBurger.getBurgerName().contains(someHint2)) {
				foundFoodItemList.add(foundBurger);
			}
		}
		
		return foundFoodItemList;
	}

	public void addPizzaService(Pizza pizza) {
		
		Optional<Pizza> objFound = pizzaRepo.findById(pizza.getPizzaId());
		if(objFound.isPresent()) {
			throw new PizzaAlreadyExistsException("Pizza with id already exist "+pizza.getPizzaId());			
		}
		else {
			pizzaRepo.save(pizza);
			System.out.println("pizza created...");
		}
	}
	public void modifyPizzaService(Pizza pizza) {
		pizzaRepo.save(pizza);
	}
	public void deletePizzaService(int pizzaId) {
		pizzaRepo.deleteById(pizzaId);
	}

	
}
