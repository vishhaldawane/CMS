
package com.cms.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.project.layer2.FoodItem;
import com.cms.project.layer2.Pizza;
import com.cms.project.layer4.FoodService;

// http://localhost:8080/food/takeOrder/veg/cheese
@RestController
@RequestMapping("/food")
public class FoodControllerImpl implements FoodController {

	@Autowired
	FoodService foodService; //controller can talk with multiple services too
	
	@GetMapping("/takeOrder/{str1}/{str2}")
	public List<FoodItem> acceptOrder(@PathVariable("str1") String hint1, @PathVariable("str2") String hint2) {
		System.out.println("FoodController : acceptOrder()");
		return foodService.orderMeal(hint1, hint2);
	}

	//post mapping means from the client the object is posted to the server to store it in DB
	@PostMapping("/addPizza") // http://localhost:8080/food/addPizza
	public String createPizza(@RequestBody Pizza pizza) {
		foodService.addPizzaService(pizza);
		return "Pizza successfully created";
	}

	//put mapping means from the client the object is modified to the server to modify it in DB
		@PutMapping("/modifyPizza") // http://localhost:8080/food/addPizza
		public String updatePizza(@RequestBody Pizza pizza) {
			foodService.modifyPizzaService(pizza);
			return "Pizza successfully modified";
		}
		
		//delete mapping means from the client the object is modified to the server to modify it in DB
				@DeleteMapping("/deletePizza/{id}") // http://localhost:8080/food/addPizza
				public String removePizza(@PathVariable("id") int pizzaId) {
					foodService.deletePizzaService(pizzaId);
					return "Pizza successfully deleted";
				}
}
