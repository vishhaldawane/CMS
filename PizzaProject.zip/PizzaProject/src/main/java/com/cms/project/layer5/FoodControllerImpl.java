
package com.cms.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.project.layer2.FoodItem;
import com.cms.project.layer2.Pizza;
import com.cms.project.layer4.FoodService;
import com.cms.project.myexceptions.MyResponse;
import com.cms.project.myexceptions.PizzaAlreadyExistsException;

// http://localhost:8080/food/takeOrder/veg/cheese
@CrossOrigin
@RestController
@RequestMapping("/food")
public class FoodControllerImpl implements FoodController {

	@Autowired
	FoodService foodService; //controller can talk with multiple services too
	
	@GetMapping("/takeOrder/{str1}/{str2}")
	public List<FoodItem> acceptOrder(@PathVariable("str1") String hint1, @PathVariable("str2") String hint2) {
		System.out.println("FoodController : acceptOrder()");
		return foodService.orderMeal(hint1, hint2);
	}

	//post mapping means from the client the object is posted to the server to store it in DB
	@PostMapping("/addPizza") // http://localhost:8080/food/addPizza
	public MyResponse createPizza(@RequestBody Pizza pizza) {
		System.out.println("CONTROLLER: pid : "+ pizza.getPizzaId());
		System.out.println("CONTROLLER: pnm :"+ pizza.getPizzaName());
		MyResponse response = new MyResponse();

		try {
			foodService.addPizzaService(pizza);
			response.setMessage("Pizza created");
			response.setStatusCode(200);

		} catch (PizzaAlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response.setMessage(e.getMessage());
			response.setStatusCode(500);

		}
		return response;
	}

	//put mapping means from the client the object is modified to the server to modify it in DB
		@PutMapping("/modifyPizza") // http://localhost:8080/food/addPizza
		public String updatePizza(@RequestBody Pizza pizza) {
			foodService.modifyPizzaService(pizza);
			return "Pizza successfully modified";
		}
		
		//delete mapping means from the client the object is modified to the server to modify it in DB
				@DeleteMapping("/deletePizza/{id}") // http://localhost:8080/food/addPizza
				public String removePizza(@PathVariable("id") int pizzaId) {
					foodService.deletePizzaService(pizzaId);
					return "Pizza successfully deleted";
				}
}
