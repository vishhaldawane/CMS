package com.cms.project.layer5;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import com.cms.project.layer2.FoodItem;
import com.cms.project.layer2.Pizza;

@RestController
public interface FoodController {
	
	List<FoodItem> acceptOrder(String hint1, String hint2);
	
	String createPizza(Pizza pizza);
	
}
