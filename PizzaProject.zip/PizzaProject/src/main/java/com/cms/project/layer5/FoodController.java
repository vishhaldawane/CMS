package com.cms.project.layer5;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.cms.project.layer2.FoodItem;
import com.cms.project.layer2.Pizza;
import com.cms.project.myexceptions.MyResponse;

@RestController
public interface FoodController {
	
	List<FoodItem> acceptOrder(String hint1, String hint2);
	
	MyResponse createPizza(Pizza pizza);
	
}
