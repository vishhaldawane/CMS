package com.cms.project;

import java.util.List;
import java.util.Scanner;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cms.project.layer2.Burger;
import com.cms.project.layer2.FoodItem;
import com.cms.project.layer2.Pizza;
import com.cms.project.layer4.FoodService;

@SpringBootTest
public class FoodServiecTesting {

	@Autowired
	FoodService foodService;
	
	
	@Test
	public void orderMealServiceTest() {
		
		Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = new Scanner(System.in);
		
		System.out.println("Enter pizza hint");
		String pizzaHint = scan1.next();
		
		System.out.println("Enter burger hint");
		String burgerHint = scan2.next();
		
		List<FoodItem> foodList = foodService.orderMeal(pizzaHint,burgerHint);
		
		for(FoodItem food: foodList) {
			if(food instanceof Pizza) {
				Pizza pizza = (Pizza) food;
				System.out.println("Pizza Id    : "+pizza.getPizzaId());			
				System.out.println("Pizza Type  : "+pizza.getPizzaName());
				System.out.println("Pizza Descr : "+pizza.getPizzaDescription());
				System.out.println("-------------------");				
			}
			else if(food instanceof Burger) {
				Burger burger = (Burger) food;
				System.out.println("Burger Id    : "+burger.getBurgerId());			
				System.out.println("Burger Type  : "+burger.getBurgerName());
				System.out.println("Burger Descr : "+burger.getBurgerDescription());
				System.out.println("-------------------");				
			} 
		}
		
	}
	
	
	@Test
	public void addPizzaServiceTest() {
		Pizza pizza = new Pizza();
		pizza.setPizzaName("Extravaganza Veg Pizza");
		pizza.setPizzaDescription("Extra veg in it");
		
		foodService.addPizzaService(pizza);
		
	}
}
