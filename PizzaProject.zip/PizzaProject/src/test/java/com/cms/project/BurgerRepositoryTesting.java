package com.cms.project;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cms.project.layer2.Burger;
import com.cms.project.layer3.BurgerRepository;

@SpringBootTest
public class BurgerRepositoryTesting {

	@Autowired
	BurgerRepository burgerRepo;
	
	@Test
	public void createBurgerTest() {
		
		Burger burger1 = new Burger();
		burger1.setBurgerName("Hamburger");
		burger1.setBurgerDescription("Large in size");
		
		Burger burger2 = new Burger();
		burger2.setBurgerName("Veg Cheese");
		burger2.setBurgerDescription("Veg is good");
		
		Burger burger3 = new Burger();
		burger3.setBurgerName("Chicken Burger");
		burger3.setBurgerDescription("Tasty one");
		
		burgerRepo.save(burger1);
		burgerRepo.save(burger2);
		burgerRepo.save(burger3);
		
		
		
	}
}
