package com.cms.project;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cms.project.layer2.Pizza;
import com.cms.project.layer3.PizzaRepository;

@SpringBootTest
class PizzaProjectApplicationTests {

	@Autowired
	PizzaRepository repo;
	
	@Test
	void contextLoads() {
		
		Pizza pizza = new Pizza();
		pizza.setPizzaId(123);
		pizza.setPizzaName("Paneer Pizza");
		pizza.setPizzaDescription("Its spice one");
		repo.save(pizza);
		
	}

}
