package com.cms.project;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cms.project.layer2.Pizza;
import com.cms.project.layer3.PizzaRepository;

@SpringBootTest
class PizzaProjectApplicationTests {

	@Autowired //FEILD LEVEL INJECTION
	PizzaRepository pizzaRepo; //just a reference | null value
	
	
	@Test
	void createPizzaTest() {
		
		Pizza pizza1 = new Pizza();
		pizza1.setPizzaName("Onion Mashroom Pizza");
		pizza1.setPizzaDescription("Its healthy one");
	
		Pizza pizza2 = new Pizza();
		pizza2.setPizzaName("Golden Corn Pizza");
		pizza2.setPizzaDescription("Its sweet one");
	
		Pizza pizza3 = new Pizza();
		pizza3.setPizzaName("Double Chicken Pizza");
		pizza3.setPizzaDescription("Its tasty one");
		
		Pizza pizza4 = new Pizza();
		pizza4.setPizzaName("Chicken Tikka Pizza");
		pizza4.setPizzaDescription("Its wow one");
		
	
		Pizza pizza5 = new Pizza();
		pizza5.setPizzaName("Extra Veg Pizza");
		pizza5.setPizzaDescription("Its good one");
		
		ArrayList<Pizza> pizzaList = new ArrayList<Pizza>();
		pizzaList.add(pizza1);
		pizzaList.add(pizza2);
		pizzaList.add(pizza3);
		pizzaList.add(pizza4);
		pizzaList.add(pizza5);
		
		pizzaRepo.saveAll(pizzaList);
		
		;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		
	}

	@Test
	public void findPizzaTest() {
		
		Optional<Pizza> anyObj = pizzaRepo.findById(10);
		if(anyObj.isPresent()) {
			Pizza pizza = anyObj.get();
			System.out.println("Pizza name : "+pizza.getPizzaName());
			System.out.println("Pizza desc : "+pizza.getPizzaDescription());
		}
		else {
			System.out.println("Pizza not there");
		}
	}
	
	
 	@Test
	public void findAllPizzasTest() {

		Iterable<Pizza> iterable = pizzaRepo.findAll();
		
		Iterator<Pizza> pizzaIterator = iterable.iterator();
		
		
		/*for (Iterator<Pizza> iterator = iterable.iterator(); iterator.hasNext();) {
			Pizza pizza = (Pizza) iterator.next();
			System.out.println("Pizza name : "+pizza.getPizzaName());
			System.out.println("Pizza desc : "+pizza.getPizzaDescription());
			System.out.println("-----------------");	
		}*/
		
		while(pizzaIterator.hasNext()) {
			Pizza pizza = pizzaIterator.next();
			System.out.println("Pizza name : "+pizza.getPizzaName());
			System.out.println("Pizza desc : "+pizza.getPizzaDescription());
			System.out.println("-----------------");
		}
	}

	
	
	@Test
	public void updatePizzaTest() {
		
		Optional<Pizza> anyObj = pizzaRepo.findById(1);
		if(anyObj.isPresent()) {
			Pizza pizza = anyObj.get();
			System.out.println("curren Pizza name : "+pizza.getPizzaName());
			System.out.println("current Pizza desc : "+pizza.getPizzaDescription());
			
			pizza.setPizzaName("PaneerTIKKA PIZZA");
			pizza.setPizzaDescription("Smoky one");
			
			pizzaRepo.save(pizza); // if the pizza id is alreay present, then it will update, else insert
			System.out.println("Pizza modified...");
		}
		else {
			System.out.println("Pizza not there");
		}
	}

	@Test
	public void deletePizzaTest() {
		//repo.deleteById(52);
		//repo.deleteById(53);
		
		Optional<Pizza> anyObj = pizzaRepo.findById(1);
		if(anyObj.isPresent()) {
			Pizza pizza = anyObj.get();
			System.out.println("curren Pizza name : "+pizza.getPizzaName());
			System.out.println("current Pizza desc : "+pizza.getPizzaDescription());
			
			
			pizzaRepo.delete(pizza); // if the pizza id is alreay present, then it will update, else insert
			System.out.println("Pizza deleted...");
		}
		else {
			System.out.println("Pizza not there");
		}
	}

}
